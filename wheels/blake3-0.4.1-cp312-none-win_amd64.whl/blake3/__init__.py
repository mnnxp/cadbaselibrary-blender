from .blake3 import *

__doc__ = blake3.__doc__
if hasattr(blake3, "__all__"):
    __all__ = blake3.__all__